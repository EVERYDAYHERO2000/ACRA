export default class Graph {

    constructor (id) {

      this._id = `#${id}`;

      return this;
    }

    setData (data) {

      this._data = data;

      return this;
    }

    setDates (dates) {

      this._rawDates = dates;
      const result = [];

      for (var i in dates) {

        result.push(dates[i]);

      }

      this._labels = result;

      return this;

    }

    drawData(step) {

        const _this = this;

        const series = (function(data){

          let result = [];

          for (var i=0; i < data.length; i++) {

            result.push({
              color : '#' + _this._map.colors.hex[ data[i].colorIndex ],
              data : (function(dates){

                let obj = JSON.parse(JSON.stringify(_this._rawDates));
                let result = [];

                for (var o in obj) {
                  obj[o] = null; 
                } 

                for (var d in dates ) {
                   
                  obj[d] = dates[d];

                }  

                for (var o in obj) {

                  result.push(obj[o]);

                }

                let last = 0;

                let vector = 0;

                for (var i = 0; i < _this._labels.length; i++) {

                  if (i == 96) {
                    if ( result[i] - result[i-1] > result[i-1] - result[i-2] ) {
                      vector = 1;
                    } else if ( result[i] - result[i-1] < result[i-1] - result[i-2] ) {
                      vector = -1;
                    }
                  }

                  if (result[i] == null) {

                    let prediction = last + (i * (Math.abs(Math.sin(last)) * vector) );
                    result[i] = (i < 96) ? last : (prediction > 0) ? prediction : 0;
                    
                  }  

                  if (result[i] != null) {
                    last = result[i];
                  }  

                }
                
                return result;

              })(data[i].dates)

            })

          }

          return result;

        })(this._data);

        this._chart = new Chartist.Line(this._id, {
            labels: this._labels,
            series: series
          }, {
            fullWidth: true,
            chartPadding: {
              right: 40
            }
          });

          this._chart.on('created', function() {
              
              const foreignObject = document.querySelectorAll('foreignObject');

              for (var f of foreignObject) {

                if (f.firstElementChild.className.includes('ct-horizontal')) {
                  f.classList.add('f-horizontal');
                }

              }

          });

          this._chart.on('draw', function(e) {

            if (e.series) {

              e.element._node.style.stroke = e.series.color;

            }  

          });  

          return this;
    }    

    setMap (map) {
      this._map = map;
      this._colors = map.colors;

      return this;
  }

}    