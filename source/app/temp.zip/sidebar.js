export default class Sidebar {

    constructor(id){
        this._id = `#${id}`;
        this._tpl = `
            <div class="sidebar__inner">
                1212
            </div>`;

        return this;
    }

    setFilter (filter) {

        this._filter = filter;

        return this;
    }

    setData (data) {
        this._data = data;

        return this;
    }

    create () {

        const _this = this;

        const container = document.querySelector(this._id);

        container.innerHTML = this._tpl;

        document.addEventListener('mousemove',function(e){

            if (e.pageY < document.body.clientHeight - document.querySelector('#graph').clientHeight) {
                
                document.querySelector(_this._id).style['pointer-events'] = 'all';

            } else {

                if (e.target.id !== 'sidebar') document.querySelector(_this._id).style['pointer-events'] = 'none';

            }

        })

        return this;
    }
    
}    