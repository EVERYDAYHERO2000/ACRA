export default class Filter {

    constructor () {
        return this;
    }    

    setData (data) {

        this._data = data;
        this._rawData = data;

        return this;
    }

    queryToArr(query) {

        let result = [];
        let max = 20;
  
        for (var i = 0; i < query.length; i++) {
  
            if (query[i].visible) {
  
                if (query[i].type == 'item') {
  
                        if (typeof query[i].value == 'object') {
  
                            let maxLength = (query[i].value.length <= max) ? query[i].value.length : max;
                            let group = [];
  
                            for (var i2 = 0; i2 < maxLength; i2++) {
  
                                group.push(query[i].value[i2]);
  
                            }
  
                            result.push({
                              group : group,
                              colorIndex : uery[i].colorIndex,
                              dates : {}
                            })
  
                        }
  
                } else {
  
                    for (var i2 = 0; i2 < query[i].value.length; i2++) {
  
                        let maxLength = (query[i].value[i2].value.length <= max) ? query[i].value[i2].value.length : max;
                        let group = [];
  
                        for (var i3 = 0; i3 < maxLength; i3++ ) {
  
                            group.push(query[i].value[i2].value[i3]);
  
                        }
  
                        result.push({
                          group : group,
                          colorIndex : query[i].value[i2].colorIndex,
                          dates : {}
                        })
  
                    }
  
                }
  
            }
  
        }
  
        return result;
    }

    setQuery (query, callback) {

        this.query = (query) ? this.queryToArr(query) : null;

        let tempData = JSON.parse(JSON.stringify(this._rawData));

        if (this.query){

            let tempDataLength = tempData.length
            for (var p = 0; p < tempDataLength; p++) {

                let tempPointLength = tempData[p][1].length;
                for (var i = 0; i < tempPointLength; i++) {

                    let tempCode = [];

                    let tempCodeLength = tempData[p][1][i][1].length;
                    let queryGroupLength = this.query.length;

                    for (var q = queryGroupLength; q--;) {

                        let queryItemLength = this.query[q].group.length;

                        for (var q2 = queryItemLength; q2--;) {

                            for (var c = tempCodeLength; c--;) {
                            
                                if (this.query[q].group[q2] == tempData[p][1][i][1][c]) {

                                    tempCode.push( [tempData[p][1][i][1][c], this.query[q].colorIndex] );

                                    if ( !this.query[q].dates[ tempData[p][1][i][0] ] ) this.query[q].dates[ tempData[p][1][i][0] ] = 0;

                                    this.query[q].dates[ tempData[p][1][i][0] ]++

                                }

                            }

                        }

                    }

                    tempData[p][1][i] = [tempData[p][1][i][0], tempCode];

                }

            }

        }
    
        this._data = tempData;

        if (callback) callback (tempData, this.query);

        return this;
    }

}    