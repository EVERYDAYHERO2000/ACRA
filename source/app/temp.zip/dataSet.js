import Loader from "./loader.js";

export default class DataSet {

    constructor (url){

        this._url = url;
        this._loader = new Loader();

        const _this = this;
        

        this._dataRequest = function(url, callback) {
    
            if (window.fetch){
              fetch(url)
              .then(response => response.json())
              .then(function(data) {

                callback(data);

              });
              
            } else {
              $.ajax({
              type: 'GET',
              url: url,
              dataType: 'json',
              success: function (data) {
                  
                callback(data);  

                }
              });
            }
            
        }
 
    }

    getDates (data) {

        const minDate = 1887;
        const maxDate = 2020;
        const minCount = 0;

        let count = minCount;

        const dateTemp = {}

        for (var i = minDate; i <= maxDate; i++) {
           if (count >= 33){
            dateTemp[count] = i;
           }
           count++;
        }  
        
        return dateTemp;

    }

    load (callback) {

        const _this = this;

        this._loader.start();

        const codes = {}

        this._dataRequest(this._url, function(data){

            _this.dates = _this.getDates(data);  

            console.log(_this.dates)

            for (var i = 0; i < data.length; i++) {

              for (var i2 = 0; i2 < data[i][1].length; i2++ ) {

                for (var i3 = 0; i3 < data[i][1][i2][1].length; i3++) {

                  let code = ((data[i][1][i2][1][i3] + '').length < 5) ? '0' + data[i][1][i2][1][i3] : '' + data[i][1][i2][1][i3];

                  data[i][1][i2][1][i3] = code;

                  if ( !codes[ code ] ) codes[ code ] = {};

                  if ( !codes[ code ].dates ) codes[ code ].dates = JSON.parse(JSON.stringify(_this.dates));

                  if ( !codes[ code ].dates[ data[i][1][i2][0] ] ) {
                    codes[ code ].dates[ data[i][1][i2][0] ].date = codes[ code ].dates[ data[i][1][i2][0] ];
                    codes[ code ].dates[ data[i][1][i2][0] ].length = 0;
                  }  

                  codes[ code ].code = code;

                  console.log(codes[ code ].dates[ data[i][1][i2][0] ], data[i][1][i2][0])

                  codes[ code ].dates[ data[i][1][i2][0] ].length++


                }

              }    

            }

            console.log(codes);

            _this._loader.finish();    

            _this.data = data;

            callback(_this.data, _this.dates);

        });

        

    }

}    